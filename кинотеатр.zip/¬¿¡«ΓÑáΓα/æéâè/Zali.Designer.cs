﻿namespace СВГК
{
    partial class Zali
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zali));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.kinoteatrDataSet = new СВГК.kinoteatrDataSet();
            this.zaliBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zaliTableAdapter = new СВГК.kinoteatrDataSetTableAdapters.zaliTableAdapter();
            this.tableAdapterManager = new СВГК.kinoteatrDataSetTableAdapters.TableAdapterManager();
            this.zaliBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.zaliBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.mestaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mestaTableAdapter = new СВГК.kinoteatrDataSetTableAdapters.mestaTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.kinoteatrDataSet1 = new СВГК.kinoteatrDataSet1();
            this.zaliBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.zaliTableAdapter1 = new СВГК.kinoteatrDataSet1TableAdapters.zaliTableAdapter();
            this.tableAdapterManager1 = new СВГК.kinoteatrDataSet1TableAdapters.TableAdapterManager();
            this.mestaTableAdapter1 = new СВГК.kinoteatrDataSet1TableAdapters.mestaTableAdapter();
            this.zaliDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mestaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mestaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dobavit = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliBindingNavigator)).BeginInit();
            this.zaliBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mestaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mestaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mestaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kinoteatrDataSet
            // 
            this.kinoteatrDataSet.DataSetName = "kinoteatrDataSet";
            this.kinoteatrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zaliBindingSource
            // 
            this.zaliBindingSource.DataMember = "zali";
            this.zaliBindingSource.DataSource = this.kinoteatrDataSet;
            // 
            // zaliTableAdapter
            // 
            this.zaliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.filmTableAdapter = null;
            this.tableAdapterManager.janriTableAdapter = null;
            this.tableAdapterManager.mestaTableAdapter = null;
            this.tableAdapterManager.seansiTableAdapter = null;
            this.tableAdapterManager.sotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = СВГК.kinoteatrDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zaliTableAdapter = this.zaliTableAdapter;
            // 
            // zaliBindingNavigator
            // 
            this.zaliBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.zaliBindingNavigator.BindingSource = this.zaliBindingSource;
            this.zaliBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.zaliBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.zaliBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.zaliBindingNavigatorSaveItem});
            this.zaliBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.zaliBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.zaliBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.zaliBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.zaliBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.zaliBindingNavigator.Name = "zaliBindingNavigator";
            this.zaliBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.zaliBindingNavigator.Size = new System.Drawing.Size(885, 25);
            this.zaliBindingNavigator.TabIndex = 0;
            this.zaliBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // zaliBindingNavigatorSaveItem
            // 
            this.zaliBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.zaliBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("zaliBindingNavigatorSaveItem.Image")));
            this.zaliBindingNavigatorSaveItem.Name = "zaliBindingNavigatorSaveItem";
            this.zaliBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.zaliBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.zaliBindingNavigatorSaveItem.Click += new System.EventHandler(this.zaliBindingNavigatorSaveItem_Click);
            // 
            // mestaBindingSource
            // 
            this.mestaBindingSource.DataMember = "mesta";
            this.mestaBindingSource.DataSource = this.kinoteatrDataSet;
            // 
            // mestaTableAdapter
            // 
            this.mestaTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.Font = new System.Drawing.Font("Cambria", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(140, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "Залы";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Brown;
            this.label2.Font = new System.Drawing.Font("Cambria", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(614, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 37);
            this.label2.TabIndex = 4;
            this.label2.Text = "Места";
            // 
            // kinoteatrDataSet1
            // 
            this.kinoteatrDataSet1.DataSetName = "kinoteatrDataSet1";
            this.kinoteatrDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zaliBindingSource1
            // 
            this.zaliBindingSource1.DataMember = "zali";
            this.zaliBindingSource1.DataSource = this.kinoteatrDataSet1;
            // 
            // zaliTableAdapter1
            // 
            this.zaliTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.filmTableAdapter = null;
            this.tableAdapterManager1.janriTableAdapter = null;
            this.tableAdapterManager1.mestaTableAdapter = this.mestaTableAdapter1;
            this.tableAdapterManager1.seansiTableAdapter = null;
            this.tableAdapterManager1.sotrudnikiTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = СВГК.kinoteatrDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager1.zaliTableAdapter = this.zaliTableAdapter1;
            // 
            // mestaTableAdapter1
            // 
            this.mestaTableAdapter1.ClearBeforeFill = true;
            // 
            // zaliDataGridView
            // 
            this.zaliDataGridView.AutoGenerateColumns = false;
            this.zaliDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.zaliDataGridView.BackgroundColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.zaliDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.zaliDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.zaliDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.zaliDataGridView.DataSource = this.zaliBindingSource1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.zaliDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.zaliDataGridView.Location = new System.Drawing.Point(0, 74);
            this.zaliDataGridView.Name = "zaliDataGridView";
            this.zaliDataGridView.Size = new System.Drawing.Size(368, 264);
            this.zaliDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 67;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Кол-во_мест";
            this.dataGridViewTextBoxColumn2.HeaderText = "Кол-во_мест";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 140;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Название";
            this.dataGridViewTextBoxColumn3.HeaderText = "Название";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 116;
            // 
            // mestaBindingSource1
            // 
            this.mestaBindingSource1.DataMember = "mesta";
            this.mestaBindingSource1.DataSource = this.kinoteatrDataSet1;
            // 
            // mestaDataGridView
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mestaDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.mestaDataGridView.AutoGenerateColumns = false;
            this.mestaDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.mestaDataGridView.BackgroundColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.mestaDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.mestaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mestaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.mestaDataGridView.DataSource = this.mestaBindingSource1;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.mestaDataGridView.DefaultCellStyle = dataGridViewCellStyle5;
            this.mestaDataGridView.Location = new System.Drawing.Point(374, 74);
            this.mestaDataGridView.Name = "mestaDataGridView";
            this.mestaDataGridView.Size = new System.Drawing.Size(514, 264);
            this.mestaDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Код";
            this.dataGridViewTextBoxColumn4.HeaderText = "Код";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 67;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Код_зала";
            this.dataGridViewTextBoxColumn5.HeaderText = "Код_зала";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 112;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Номер_ряда";
            this.dataGridViewTextBoxColumn6.HeaderText = "Номер_ряда";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 139;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Номер_места";
            this.dataGridViewTextBoxColumn7.HeaderText = "Номер_места";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 147;
            // 
            // dobavit
            // 
            this.dobavit.BackColor = System.Drawing.Color.White;
            this.dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dobavit.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dobavit.ForeColor = System.Drawing.Color.Brown;
            this.dobavit.Location = new System.Drawing.Point(165, 363);
            this.dobavit.Name = "dobavit";
            this.dobavit.Size = new System.Drawing.Size(203, 35);
            this.dobavit.TabIndex = 5;
            this.dobavit.Text = "Добавить";
            this.dobavit.UseVisualStyleBackColor = false;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.White;
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete.ForeColor = System.Drawing.Color.Brown;
            this.delete.Location = new System.Drawing.Point(374, 363);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(203, 35);
            this.delete.TabIndex = 6;
            this.delete.Text = "Удалить";
            this.delete.UseVisualStyleBackColor = false;
            // 
            // Zali
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.BackgroundImage = global::СВГК.Properties.Resources.CL8BycfcK5opSLz3oLiDC2g4UaJjfVNKavGhNF6GYIlFvNDi4xgwP5HrX4Bx6KB_fCqCHC0ES3mrWnt30Y_9X2CO;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(885, 420);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.dobavit);
            this.Controls.Add(this.mestaDataGridView);
            this.Controls.Add(this.zaliDataGridView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.zaliBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Zali";
            this.Text = "Залы";
            this.Load += new System.EventHandler(this.Zali_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliBindingNavigator)).EndInit();
            this.zaliBindingNavigator.ResumeLayout(false);
            this.zaliBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mestaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaliDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mestaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mestaDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private kinoteatrDataSet kinoteatrDataSet;
        private System.Windows.Forms.BindingSource zaliBindingSource;
        private kinoteatrDataSetTableAdapters.zaliTableAdapter zaliTableAdapter;
        private kinoteatrDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator zaliBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton zaliBindingNavigatorSaveItem;
        private System.Windows.Forms.BindingSource mestaBindingSource;
        private kinoteatrDataSetTableAdapters.mestaTableAdapter mestaTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private kinoteatrDataSet1 kinoteatrDataSet1;
        private System.Windows.Forms.BindingSource zaliBindingSource1;
        private kinoteatrDataSet1TableAdapters.zaliTableAdapter zaliTableAdapter1;
        private kinoteatrDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private kinoteatrDataSet1TableAdapters.mestaTableAdapter mestaTableAdapter1;
        private System.Windows.Forms.DataGridView zaliDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource mestaBindingSource1;
        private System.Windows.Forms.DataGridView mestaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button dobavit;
        private System.Windows.Forms.Button delete;
    }
}