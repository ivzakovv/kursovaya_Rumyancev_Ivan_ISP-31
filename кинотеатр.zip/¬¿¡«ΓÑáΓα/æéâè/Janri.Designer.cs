﻿namespace СВГК
{
    partial class Janri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Janri));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.kinoteatrDataSet = new СВГК.kinoteatrDataSet();
            this.janriBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.janriTableAdapter = new СВГК.kinoteatrDataSetTableAdapters.janriTableAdapter();
            this.tableAdapterManager = new СВГК.kinoteatrDataSetTableAdapters.TableAdapterManager();
            this.janriBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.janriBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.kinoteatrDataSet1 = new СВГК.kinoteatrDataSet1();
            this.janriBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.janriTableAdapter1 = new СВГК.kinoteatrDataSet1TableAdapters.janriTableAdapter();
            this.tableAdapterManager1 = new СВГК.kinoteatrDataSet1TableAdapters.TableAdapterManager();
            this.janriDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delete = new System.Windows.Forms.Button();
            this.dobavit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingNavigator)).BeginInit();
            this.janriBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kinoteatrDataSet
            // 
            this.kinoteatrDataSet.DataSetName = "kinoteatrDataSet";
            this.kinoteatrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // janriBindingSource
            // 
            this.janriBindingSource.DataMember = "janri";
            this.janriBindingSource.DataSource = this.kinoteatrDataSet;
            // 
            // janriTableAdapter
            // 
            this.janriTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.filmTableAdapter = null;
            this.tableAdapterManager.janriTableAdapter = this.janriTableAdapter;
            this.tableAdapterManager.mestaTableAdapter = null;
            this.tableAdapterManager.seansiTableAdapter = null;
            this.tableAdapterManager.sotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = СВГК.kinoteatrDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zaliTableAdapter = null;
            // 
            // janriBindingNavigator
            // 
            this.janriBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.janriBindingNavigator.BindingSource = this.janriBindingSource;
            this.janriBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.janriBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.janriBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.janriBindingNavigatorSaveItem});
            this.janriBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.janriBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.janriBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.janriBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.janriBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.janriBindingNavigator.Name = "janriBindingNavigator";
            this.janriBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.janriBindingNavigator.Size = new System.Drawing.Size(343, 25);
            this.janriBindingNavigator.TabIndex = 0;
            this.janriBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // janriBindingNavigatorSaveItem
            // 
            this.janriBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.janriBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("janriBindingNavigatorSaveItem.Image")));
            this.janriBindingNavigatorSaveItem.Name = "janriBindingNavigatorSaveItem";
            this.janriBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.janriBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.janriBindingNavigatorSaveItem.Click += new System.EventHandler(this.janriBindingNavigatorSaveItem_Click);
            // 
            // kinoteatrDataSet1
            // 
            this.kinoteatrDataSet1.DataSetName = "kinoteatrDataSet1";
            this.kinoteatrDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // janriBindingSource1
            // 
            this.janriBindingSource1.DataMember = "janri";
            this.janriBindingSource1.DataSource = this.kinoteatrDataSet1;
            // 
            // janriTableAdapter1
            // 
            this.janriTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.filmTableAdapter = null;
            this.tableAdapterManager1.janriTableAdapter = this.janriTableAdapter1;
            this.tableAdapterManager1.mestaTableAdapter = null;
            this.tableAdapterManager1.seansiTableAdapter = null;
            this.tableAdapterManager1.sotrudnikiTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = СВГК.kinoteatrDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager1.zaliTableAdapter = null;
            // 
            // janriDataGridView
            // 
            this.janriDataGridView.AutoGenerateColumns = false;
            this.janriDataGridView.BackgroundColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.janriDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.janriDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.janriDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.janriDataGridView.DataSource = this.janriBindingSource1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.janriDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.janriDataGridView.Location = new System.Drawing.Point(0, 25);
            this.janriDataGridView.Name = "janriDataGridView";
            this.janriDataGridView.Size = new System.Drawing.Size(343, 255);
            this.janriDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Название";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Описание";
            this.dataGridViewTextBoxColumn3.HeaderText = "Описание";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.White;
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete.ForeColor = System.Drawing.Color.Brown;
            this.delete.Location = new System.Drawing.Point(179, 307);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(110, 35);
            this.delete.TabIndex = 8;
            this.delete.Text = "Удалить";
            this.delete.UseVisualStyleBackColor = false;
            // 
            // dobavit
            // 
            this.dobavit.BackColor = System.Drawing.Color.White;
            this.dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dobavit.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dobavit.ForeColor = System.Drawing.Color.Brown;
            this.dobavit.Location = new System.Drawing.Point(48, 307);
            this.dobavit.Name = "dobavit";
            this.dobavit.Size = new System.Drawing.Size(110, 35);
            this.dobavit.TabIndex = 7;
            this.dobavit.Text = "Добавить";
            this.dobavit.UseVisualStyleBackColor = false;
            // 
            // Janri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.BackgroundImage = global::СВГК.Properties.Resources.CL8BycfcK5opSLz3oLiDC2g4UaJjfVNKavGhNF6GYIlFvNDi4xgwP5HrX4Bx6KB_fCqCHC0ES3mrWnt30Y_9X2CO;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(343, 354);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.dobavit);
            this.Controls.Add(this.janriDataGridView);
            this.Controls.Add(this.janriBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Janri";
            this.Text = "Жанры";
            this.Load += new System.EventHandler(this.Janri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingNavigator)).EndInit();
            this.janriBindingNavigator.ResumeLayout(false);
            this.janriBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private kinoteatrDataSet kinoteatrDataSet;
        private System.Windows.Forms.BindingSource janriBindingSource;
        private kinoteatrDataSetTableAdapters.janriTableAdapter janriTableAdapter;
        private kinoteatrDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator janriBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton janriBindingNavigatorSaveItem;
        private kinoteatrDataSet1 kinoteatrDataSet1;
        private System.Windows.Forms.BindingSource janriBindingSource1;
        private kinoteatrDataSet1TableAdapters.janriTableAdapter janriTableAdapter1;
        private kinoteatrDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView janriDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button dobavit;
    }
}