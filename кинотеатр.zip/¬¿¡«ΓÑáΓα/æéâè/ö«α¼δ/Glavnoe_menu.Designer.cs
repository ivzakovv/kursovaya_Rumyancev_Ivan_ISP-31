﻿namespace СВГК
{
    partial class Glavnoe_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Glavnoe_menu));
            this.label1 = new System.Windows.Forms.Label();
            this.fio = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.seansi = new System.Windows.Forms.Button();
            this.sotr = new System.Windows.Forms.Button();
            this.barcodes = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.zali = new System.Windows.Forms.Button();
            this.janri = new System.Windows.Forms.Button();
            this.films = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Cambria", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(224, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 57);
            this.label1.TabIndex = 2;
            this.label1.Text = "CoolMovie";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // fio
            // 
            this.fio.AutoSize = true;
            this.fio.BackColor = System.Drawing.Color.Brown;
            this.fio.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fio.ForeColor = System.Drawing.Color.White;
            this.fio.Location = new System.Drawing.Point(487, 428);
            this.fio.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.fio.Name = "fio";
            this.fio.Size = new System.Drawing.Size(33, 19);
            this.fio.TabIndex = 3;
            this.fio.Text = "FIO";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // seansi
            // 
            this.seansi.BackColor = System.Drawing.Color.Brown;
            this.seansi.ForeColor = System.Drawing.Color.White;
            this.seansi.Location = new System.Drawing.Point(343, 80);
            this.seansi.Name = "seansi";
            this.seansi.Size = new System.Drawing.Size(189, 70);
            this.seansi.TabIndex = 4;
            this.seansi.Text = "СЕАНСЫ";
            this.seansi.UseVisualStyleBackColor = false;
            this.seansi.Click += new System.EventHandler(this.seansi_Click);
            // 
            // sotr
            // 
            this.sotr.BackColor = System.Drawing.Color.Brown;
            this.sotr.ForeColor = System.Drawing.Color.White;
            this.sotr.Location = new System.Drawing.Point(132, 234);
            this.sotr.Name = "sotr";
            this.sotr.Size = new System.Drawing.Size(189, 70);
            this.sotr.TabIndex = 5;
            this.sotr.Text = "СОТРУДНИКИ";
            this.sotr.UseVisualStyleBackColor = false;
            this.sotr.Click += new System.EventHandler(this.sotr_Click);
            // 
            // barcodes
            // 
            this.barcodes.BackColor = System.Drawing.Color.Brown;
            this.barcodes.ForeColor = System.Drawing.Color.White;
            this.barcodes.Location = new System.Drawing.Point(343, 234);
            this.barcodes.Name = "barcodes";
            this.barcodes.Size = new System.Drawing.Size(189, 70);
            this.barcodes.TabIndex = 6;
            this.barcodes.Text = "ШТРИХКОДЫ";
            this.barcodes.UseVisualStyleBackColor = false;
            this.barcodes.Click += new System.EventHandler(this.barcodes_Click_1);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Brown;
            this.exit.ForeColor = System.Drawing.Color.White;
            this.exit.Location = new System.Drawing.Point(234, 328);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(189, 70);
            this.exit.TabIndex = 7;
            this.exit.Text = "ВЫХОД";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // zali
            // 
            this.zali.BackColor = System.Drawing.Color.Brown;
            this.zali.ForeColor = System.Drawing.Color.White;
            this.zali.Location = new System.Drawing.Point(343, 154);
            this.zali.Name = "zali";
            this.zali.Size = new System.Drawing.Size(189, 74);
            this.zali.TabIndex = 8;
            this.zali.Text = "ЗАЛЫ И МЕСТА";
            this.zali.UseVisualStyleBackColor = false;
            this.zali.Click += new System.EventHandler(this.zali_Click);
            // 
            // janri
            // 
            this.janri.BackColor = System.Drawing.Color.Brown;
            this.janri.ForeColor = System.Drawing.Color.White;
            this.janri.Location = new System.Drawing.Point(132, 156);
            this.janri.Name = "janri";
            this.janri.Size = new System.Drawing.Size(189, 72);
            this.janri.TabIndex = 9;
            this.janri.Text = "ЖАНРЫ";
            this.janri.UseVisualStyleBackColor = false;
            this.janri.Click += new System.EventHandler(this.janri_Click);
            // 
            // films
            // 
            this.films.BackColor = System.Drawing.Color.Brown;
            this.films.ForeColor = System.Drawing.Color.White;
            this.films.Location = new System.Drawing.Point(132, 80);
            this.films.Name = "films";
            this.films.Size = new System.Drawing.Size(189, 70);
            this.films.TabIndex = 10;
            this.films.Text = "ФИЛЬМЫ";
            this.films.UseVisualStyleBackColor = false;
            this.films.Click += new System.EventHandler(this.button7_Click);
            // 
            // Glavnoe_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.BackgroundImage = global::СВГК.Properties.Resources.CL8BycfcK5opSLz3oLiDC2g4UaJjfVNKavGhNF6GYIlFvNDi4xgwP5HrX4Bx6KB_fCqCHC0ES3mrWnt30Y_9X2CO;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(654, 491);
            this.Controls.Add(this.films);
            this.Controls.Add(this.janri);
            this.Controls.Add(this.zali);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.barcodes);
            this.Controls.Add(this.sotr);
            this.Controls.Add(this.seansi);
            this.Controls.Add(this.fio);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Glavnoe_menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главное меню";
            this.Load += new System.EventHandler(this.Glavnoe_menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label fio;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button seansi;
        private System.Windows.Forms.Button sotr;
        private System.Windows.Forms.Button barcodes;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button zali;
        private System.Windows.Forms.Button janri;
        private System.Windows.Forms.Button films;
    }
}