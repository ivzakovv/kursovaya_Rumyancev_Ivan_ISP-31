﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СВГК
{
    public partial class Glavnoe_menu : Form
    {
        public Glavnoe_menu()
        {
            InitializeComponent();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client cl = new Client();
            cl.Show();
        }

        private void проектыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Films pr = new Films();
            pr.Show();
        }


        private void выполнениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Seansi perf = new Seansi();
            perf.Show();
        }


        private void выйтиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Autorization autoriz = new Autorization();
            autoriz.Show();
            Hide();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void поставкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Janri janr = new Janri();
            janr.Show();
        }

        private void поставкиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Zali zali = new Zali();
            zali.Show();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sotrudniki sotr = new Sotrudniki();
            sotr.Show();
        }

        private void Glavnoe_menu_Load(object sender, EventArgs e)
        {

        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void barcodes_Click(object sender, EventArgs e)
        {
           

        }

        private void штрихкодыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Barcode bar = new Barcode();
            bar.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Films pr = new Films();
            pr.Show();
        }

        private void seansi_Click(object sender, EventArgs e)
        {
            Seansi perf = new Seansi();
            perf.Show();
        }

        private void janri_Click(object sender, EventArgs e)
        {
            Janri janr = new Janri();
            janr.Show();
        }

        private void zali_Click(object sender, EventArgs e)
        {
            Zali zali = new Zali();
            zali.Show();
        }

        private void sotr_Click(object sender, EventArgs e)
        {
            Sotrudniki sotr = new Sotrudniki();
            sotr.Show();
        }

        private void barcodes_Click_1(object sender, EventArgs e)
        {
            Barcode bar = new Barcode();
            bar.Show();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Autorization autoriz = new Autorization();
            autoriz.Show();
            Hide();

        }
    }
}
