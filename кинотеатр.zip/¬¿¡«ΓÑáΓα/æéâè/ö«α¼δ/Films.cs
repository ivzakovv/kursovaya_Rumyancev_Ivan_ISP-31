﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СВГК
{
    public partial class Films : Form
    {
        public Films()
        {
            InitializeComponent();
        }

        private void проектBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           
        }

        private void Projects_Load(object sender, EventArgs e)
        {
          

        }

        private void проектированиеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           

        }

        private void filmBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.filmBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kinoteatrDataSet);

        }

        private void Films_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kinoteatrDataSet1.film". При необходимости она может быть перемещена или удалена.
            this.filmTableAdapter1.Fill(this.kinoteatrDataSet1.film);
           

        }
    }
}
