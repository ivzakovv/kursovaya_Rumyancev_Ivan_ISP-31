﻿namespace СВГК
{
    partial class Seansi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Seansi));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.kinoteatrDataSet = new СВГК.kinoteatrDataSet();
            this.seansiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.seansiTableAdapter = new СВГК.kinoteatrDataSetTableAdapters.seansiTableAdapter();
            this.tableAdapterManager = new СВГК.kinoteatrDataSetTableAdapters.TableAdapterManager();
            this.seansiBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.seansiBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.kinoteatrDataSet1 = new СВГК.kinoteatrDataSet1();
            this.seansiBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.seansiTableAdapter1 = new СВГК.kinoteatrDataSet1TableAdapters.seansiTableAdapter();
            this.tableAdapterManager1 = new СВГК.kinoteatrDataSet1TableAdapters.TableAdapterManager();
            this.seansiDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delete = new System.Windows.Forms.Button();
            this.dobavit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiBindingNavigator)).BeginInit();
            this.seansiBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kinoteatrDataSet
            // 
            this.kinoteatrDataSet.DataSetName = "kinoteatrDataSet";
            this.kinoteatrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seansiBindingSource
            // 
            this.seansiBindingSource.DataMember = "seansi";
            this.seansiBindingSource.DataSource = this.kinoteatrDataSet;
            // 
            // seansiTableAdapter
            // 
            this.seansiTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.filmTableAdapter = null;
            this.tableAdapterManager.janriTableAdapter = null;
            this.tableAdapterManager.mestaTableAdapter = null;
            this.tableAdapterManager.seansiTableAdapter = this.seansiTableAdapter;
            this.tableAdapterManager.sotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = СВГК.kinoteatrDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zaliTableAdapter = null;
            // 
            // seansiBindingNavigator
            // 
            this.seansiBindingNavigator.AddNewItem = this.toolStripButton5;
            this.seansiBindingNavigator.BindingSource = this.seansiBindingSource;
            this.seansiBindingNavigator.CountItem = this.toolStripLabel1;
            this.seansiBindingNavigator.DeleteItem = this.toolStripButton6;
            this.seansiBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator3,
            this.toolStripButton5,
            this.toolStripButton6,
            this.seansiBindingNavigatorSaveItem});
            this.seansiBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.seansiBindingNavigator.MoveFirstItem = this.toolStripButton1;
            this.seansiBindingNavigator.MoveLastItem = this.toolStripButton4;
            this.seansiBindingNavigator.MoveNextItem = this.toolStripButton3;
            this.seansiBindingNavigator.MovePreviousItem = this.toolStripButton2;
            this.seansiBindingNavigator.Name = "seansiBindingNavigator";
            this.seansiBindingNavigator.PositionItem = this.toolStripTextBox1;
            this.seansiBindingNavigator.Size = new System.Drawing.Size(959, 25);
            this.seansiBindingNavigator.TabIndex = 0;
            this.seansiBindingNavigator.Text = "bindingNavigator1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Добавить";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel1.Text = "для {0}";
            this.toolStripLabel1.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Удалить";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "Переместить в начало";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Переместить назад";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Положение";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Переместить вперед";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Переместить в конец";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // seansiBindingNavigatorSaveItem
            // 
            this.seansiBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.seansiBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("seansiBindingNavigatorSaveItem.Image")));
            this.seansiBindingNavigatorSaveItem.Name = "seansiBindingNavigatorSaveItem";
            this.seansiBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.seansiBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.seansiBindingNavigatorSaveItem.Click += new System.EventHandler(this.seansiBindingNavigatorSaveItem_Click);
            // 
            // kinoteatrDataSet1
            // 
            this.kinoteatrDataSet1.DataSetName = "kinoteatrDataSet1";
            this.kinoteatrDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seansiBindingSource1
            // 
            this.seansiBindingSource1.DataMember = "seansi";
            this.seansiBindingSource1.DataSource = this.kinoteatrDataSet1;
            // 
            // seansiTableAdapter1
            // 
            this.seansiTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.filmTableAdapter = null;
            this.tableAdapterManager1.janriTableAdapter = null;
            this.tableAdapterManager1.mestaTableAdapter = null;
            this.tableAdapterManager1.seansiTableAdapter = this.seansiTableAdapter1;
            this.tableAdapterManager1.sotrudnikiTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = СВГК.kinoteatrDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager1.zaliTableAdapter = null;
            // 
            // seansiDataGridView
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            this.seansiDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.seansiDataGridView.AutoGenerateColumns = false;
            this.seansiDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.seansiDataGridView.BackgroundColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.seansiDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.seansiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.seansiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.seansiDataGridView.DataSource = this.seansiBindingSource1;
            this.seansiDataGridView.Location = new System.Drawing.Point(0, 24);
            this.seansiDataGridView.Name = "seansiDataGridView";
            this.seansiDataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            this.seansiDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.seansiDataGridView.Size = new System.Drawing.Size(961, 334);
            this.seansiDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Код";
            this.dataGridViewTextBoxColumn5.HeaderText = "Код";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 67;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Код_сотрудника";
            this.dataGridViewTextBoxColumn6.HeaderText = "Код_сотрудника";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 174;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Код_зала";
            this.dataGridViewTextBoxColumn7.HeaderText = "Код_зала";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 112;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Код_фильма";
            this.dataGridViewTextBoxColumn8.HeaderText = "Код_фильма";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 141;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Код_места";
            this.dataGridViewTextBoxColumn9.HeaderText = "Код_места";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 123;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Дата";
            this.dataGridViewTextBoxColumn10.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 75;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Время";
            this.dataGridViewTextBoxColumn11.HeaderText = "Время";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 90;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn12.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 128;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.White;
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete.ForeColor = System.Drawing.Color.Brown;
            this.delete.Location = new System.Drawing.Point(526, 364);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(110, 35);
            this.delete.TabIndex = 8;
            this.delete.Text = "Удалить";
            this.delete.UseVisualStyleBackColor = false;
            // 
            // dobavit
            // 
            this.dobavit.BackColor = System.Drawing.Color.White;
            this.dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dobavit.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dobavit.ForeColor = System.Drawing.Color.Brown;
            this.dobavit.Location = new System.Drawing.Point(395, 364);
            this.dobavit.Name = "dobavit";
            this.dobavit.Size = new System.Drawing.Size(110, 35);
            this.dobavit.TabIndex = 7;
            this.dobavit.Text = "Добавить";
            this.dobavit.UseVisualStyleBackColor = false;
            // 
            // Seansi
            // 
            this.BackColor = System.Drawing.Color.Thistle;
            this.BackgroundImage = global::СВГК.Properties.Resources.CL8BycfcK5opSLz3oLiDC2g4UaJjfVNKavGhNF6GYIlFvNDi4xgwP5HrX4Bx6KB_fCqCHC0ES3mrWnt30Y_9X2CO;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(959, 404);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.dobavit);
            this.Controls.Add(this.seansiDataGridView);
            this.Controls.Add(this.seansiBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Seansi";
            this.Text = "Сеансы";
            this.Load += new System.EventHandler(this.Seansi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiBindingNavigator)).EndInit();
            this.seansiBindingNavigator.ResumeLayout(false);
            this.seansiBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kinoteatrDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seansiDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

       
        private System.Windows.Forms.BindingNavigator монтажные_раюотыBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton монтажные_раюотыBindingNavigatorSaveItem;
       
        private System.Windows.Forms.BindingSource avtorBindingSource;
       
        private System.Windows.Forms.DataGridView avtorDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource janriBindingSource;
        private System.Windows.Forms.DataGridView janriDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private kinoteatrDataSet kinoteatrDataSet;
        private System.Windows.Forms.BindingSource seansiBindingSource;
        private kinoteatrDataSetTableAdapters.seansiTableAdapter seansiTableAdapter;
        private kinoteatrDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator seansiBindingNavigator;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton seansiBindingNavigatorSaveItem;
        private kinoteatrDataSet1 kinoteatrDataSet1;
        private System.Windows.Forms.BindingSource seansiBindingSource1;
        private kinoteatrDataSet1TableAdapters.seansiTableAdapter seansiTableAdapter1;
        private kinoteatrDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView seansiDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button dobavit;
    }
}